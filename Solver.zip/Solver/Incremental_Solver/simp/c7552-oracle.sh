#!/bin/bash

echo "hello world"
python Oracle.py c7552-abcmap-fmt.v PI.txt PO.txt
