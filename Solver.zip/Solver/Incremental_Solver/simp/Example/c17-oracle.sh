#!/bin/bash

echo "hello world"
python Oracle.py c17-abcmap-fmt.v PI.txt PO.txt
